<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

	
	public function login()
	{
		$this->load->view('login');
	}
    public function register()
	{
		$this->load->view('register');
	}
    public function home()
	{
		$this->load->view('home');
	}
    public function about()
	{
		$this->load->view('about');
	}
}
